﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.SignalR;

namespace TaskManagement.Api.Models;

public class User: IdentityUser
{
    

}
