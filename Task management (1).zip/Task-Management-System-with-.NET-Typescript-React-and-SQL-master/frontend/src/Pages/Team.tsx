import React from 'react'

function Team() {
  return (
    <div>Team</div>
  )
}

export default Team