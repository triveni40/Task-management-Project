export type AuthState= {
    user: string | null;
    token: string | null;
    role: string | null;
  }
  